library(testthat)
library(RAQSAPI)

test_check("RAQSAPI")
